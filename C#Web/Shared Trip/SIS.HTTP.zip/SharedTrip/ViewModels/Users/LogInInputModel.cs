﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SharedTrip.ViewModels.Users
{
    public class LogInInputModel
    {
        public string Username { get; set; }

        public string Password { get; set; }
    }
}
