﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SharedTrip.ViewModels.Home
{
    public class IndexViewModel
    {
        public string Username { get; set; }
    }
}
