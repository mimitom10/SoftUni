﻿namespace SharedTrip
{
    public class DatabaseConfiguration
    {
        public const string ConnectionString =
           "Server=DESKTOP-PAM8VE0\\SQLEXPRESS;Database=App/mimitom10;Integrated Security=True;";
    }
}